package clases;

public class Estudiante {
    private String cedula;
    private String nombre; // Nuevo atributo para el nombre
    private boolean estado;

    public Estudiante(String cedula, String nombre, boolean estado) {
        this.cedula = cedula;
        this.nombre = nombre; // Inicializar el nombre
        this.estado = estado;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre; // Método para obtener el nombre
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}





