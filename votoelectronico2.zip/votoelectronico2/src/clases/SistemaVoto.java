package clases;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SistemaVoto extends JFrame {
    private static List<Estudiante> estudiantes = new ArrayList<>();
    private static List<Candidato> candidatos = new ArrayList<>();
    private static List<Voto> votos = new ArrayList<>();
    private static List<Mesa> mesas = new ArrayList<>();
    private static List<Curso> cursos = new ArrayList<>();
    private static int votoId = 1;

    public SistemaVoto() {
        setTitle("Sistema de Voto");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        inicializarDatos();
        crearMenu();
    }

    private void inicializarDatos() {
    // Agregar candidatos
        candidatos.add(new Candidato("Candidato A", "Partido A"));
        candidatos.add(new Candidato("Candidato B", "Partido B"));
        
        // Agregar mesas y cursos iniciales
        mesas.add(new Mesa("Mesa 1"));
        mesas.add(new Mesa("Mesa 2"));
        cursos.add(new Curso("Curso 1"));
        cursos.add(new Curso("Curso 2"));
    }

    private void crearMenu() {
        JMenuBar menuBar = new JMenuBar();

        // Menú Archivo
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem itemSalir = new JMenuItem("Salir");
        itemSalir.addActionListener(e -> System.exit(0));
        menuArchivo.add(itemSalir);
        menuBar.add(menuArchivo);

        // Menú Administración
        JMenu menuAdministracion = new JMenu("Administración");
        
        JMenuItem itemMesas = new JMenuItem("Mesas");
        itemMesas.addActionListener(e -> gestionarMesas());
        
        JMenuItem itemCursos = new JMenuItem("Cursos");
        itemCursos.addActionListener(e -> gestionarCursos());
        
        JMenuItem itemEstudiantes = new JMenuItem("Estudiantes");
        itemEstudiantes.addActionListener(e -> registrarEstudiante());
        
        JMenuItem itemCandidatos = new JMenuItem("Candidatos");
        itemCandidatos.addActionListener(e -> registrarCandidato());
        
        menuAdministracion.add(itemMesas);
        menuAdministracion.add(itemCursos);
        menuAdministracion.add(itemEstudiantes);
        menuAdministracion.add(itemCandidatos);
        menuBar.add(menuAdministracion);

        // Menú Proceso
        JMenu menuProceso = new JMenu("Proceso");
        JMenuItem itemSufragar = new JMenuItem("Sufragar");
        itemSufragar.addActionListener(e -> sufragar());
        menuProceso.add(itemSufragar);
        menuBar.add(menuProceso);

        // Menú Reportes
        JMenu menuReportes = new JMenu("Reportes");
        JMenuItem itemPadron = new JMenuItem("Padrón electoral");
        itemPadron.addActionListener(e -> mostrarPadronElectoral());
        JMenuItem itemResultados = new JMenuItem("Resultados generales");
        itemResultados.addActionListener(e -> mostrarResultadosGenerales());
        menuReportes.add(itemPadron);
        menuReportes.add(itemResultados);
        menuBar.add(menuReportes);

        setJMenuBar(menuBar);
    }

    private void gestionarMesas() {
        String[] opciones = {"Registrar Mesa", "Listar Mesas"};
        int seleccion = JOptionPane.showOptionDialog(this, "Seleccione una opción:", "Mesas",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        switch (seleccion) {
            case 0:
                registrarMesa();
                break;
            case 1:
                listarMesas();
                break;
            default:
                break;
        }
    }

    private void registrarMesa() {
        String nombreMesa = JOptionPane.showInputDialog(this, "Ingrese el nombre de la mesa:");
        if (nombreMesa != null && !nombreMesa.isEmpty()) {
            mesas.add(new Mesa(nombreMesa));
            JOptionPane.showMessageDialog(this, "Mesa registrada exitosamente.");
        }
    }

    private void listarMesas() {
        StringBuilder listaMesas = new StringBuilder("Mesas registradas:\n");
        for (Mesa mesa : mesas) {
            listaMesas.append(mesa.getNombre()).append("\n");
        }
        JOptionPane.showMessageDialog(this, listaMesas.toString());
    }

    private void gestionarCursos() {
        String[] opciones = {"Registrar Curso", "Listar Cursos"};
        int seleccion = JOptionPane.showOptionDialog(this, "Seleccione una opción:", "Cursos",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        switch (seleccion) {
            case 0:
                registrarCurso();
                break;
            case 1:
                listarCursos();
                break;
            default:
                break;
        }
    }

    private void registrarCurso() {
        String nombreCurso = JOptionPane.showInputDialog(this, "Ingrese el nombre del curso:");
        if (nombreCurso != null && !nombreCurso.isEmpty()) {
            cursos.add(new Curso(nombreCurso));
            JOptionPane.showMessageDialog(this, "Curso registrado exitosamente.");
        }
    }

    private void listarCursos() {
        StringBuilder listaCursos = new StringBuilder("Cursos registrados:\n");
        for (Curso curso : cursos) {
            listaCursos.append(curso.getNombre()).append("\n");
        }
        JOptionPane.showMessageDialog(this, listaCursos.toString());
    }

    private void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    private void registrarEstudiante() {
        String cedula = JOptionPane.showInputDialog(this, "Ingrese la cédula del estudiante:");
        String nombre = JOptionPane.showInputDialog(this, "Ingrese el nombre del estudiante:"); // Solicitar nombre
        if (cedula != null && !cedula.isEmpty() && nombre != null && !nombre.isEmpty()) {
            estudiantes.add(new Estudiante(cedula, nombre, false)); // Guardar nombre junto a la cédula
            JOptionPane.showMessageDialog(this, "Estudiante registrado exitosamente.");
        }
    }


    private void registrarCandidato() {
        String nombre = JOptionPane.showInputDialog(this, "Ingrese el nombre del candidato:");
        String partido = JOptionPane.showInputDialog(this, "Ingrese el partido del candidato:");
        if (nombre != null && partido != null) {
            candidatos.add(new Candidato(nombre, partido));
            JOptionPane.showMessageDialog(this, "Candidato registrado exitosamente.");
        }
    }

    private Estudiante solicitarCedula() {
        String cedula = JOptionPane.showInputDialog(this, "Ingrese su cédula:");
        return estudiantes.stream()
                .filter(e -> e.getCedula().equals(cedula) && !e.isEstado())
                .findFirst()
                .orElse(null);
    }

    private Candidato seleccionarCandidato() {
        StringBuilder candidatosList = new StringBuilder("Escoja su candidato:\n");
        for (int i = 0; i < candidatos.size(); i++) {
            candidatosList.append(i + 1).append(". ").append(candidatos.get(i).getNombre())
                    .append(" - ").append(candidatos.get(i).getPartido()).append("\n");
        }
        candidatosList.append(candidatos.size() + 1).append(". Blanco\n");
        candidatosList.append(candidatos.size() + 2).append(". Nulo\n");

        String seleccion = JOptionPane.showInputDialog(this, candidatosList.toString());
        int index = Integer.parseInt(seleccion) - 1;

        if (index >= 0 && index < candidatos.size()) {
            return candidatos.get(index);
        } else if (index == candidatos.size()) {
            return null; // Voto en blanco
        } else if (index == candidatos.size() + 1) {
            return null; // Voto nulo
        }

        return null;
    }

    private void mostrarAgradecimiento() {
        JOptionPane.showMessageDialog(this, "Gracias por su voto.");
    }

    private void sufragar() {
        Estudiante estudiante = solicitarCedula();

        if (estudiante != null) {
            Candidato candidato = seleccionarCandidato();
            
            if (candidato != null) {
                Voto voto = new Voto(votoId++, estudiante, candidato);
                votos.add(voto);
                estudiante.setEstado(true);
                mostrarAgradecimiento();
            } else {
                JOptionPane.showMessageDialog(this, "Voto en blanco o nulo registrado.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Estudiante no encontrado o ya ha votado.");
        }
    }

    private void mostrarPadronElectoral() {
        StringBuilder padron = new StringBuilder("Padrón electoral:\n");
        for (Estudiante estudiante : estudiantes) {
            padron.append(estudiante.getCedula()).append(" - ").append(estudiante.getNombre()).append("\n"); // Mostrar cédula y nombre
        }
        JOptionPane.showMessageDialog(this, padron.toString());
    }


    private void mostrarResultadosGenerales() {
        StringBuilder resultados = new StringBuilder("Resultados:\n");
        for (Candidato candidato : candidatos) {
            long totalVotos = votos.stream().filter(v -> v.getCandidato().equals(candidato)).count();
            resultados.append(candidato.getNombre()).append(" - ").append(totalVotos).append(" votos\n");
        }
        JOptionPane.showMessageDialog(this, resultados.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SistemaVoto sistemaVoto = new SistemaVoto();
            sistemaVoto.setVisible(true);
        });
    }
}


