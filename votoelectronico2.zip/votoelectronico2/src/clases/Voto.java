package clases;

public class Voto {
    private int id;
    private Estudiante estudiante;
    private Candidato candidato;

    public Voto(int id, Estudiante estudiante, Candidato candidato) {
        this.id = id;
        this.estudiante = estudiante;
        this.candidato = candidato;
    }

    // Getters y Setters
    public Long getId() { return (long) id; }
    public Estudiante getEstudiante() { return estudiante; }
    public Candidato getCandidato() { return candidato; }
}
