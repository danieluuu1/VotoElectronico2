package clases;

public class Mesa {
    private String nombre;

    public Mesa(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}


